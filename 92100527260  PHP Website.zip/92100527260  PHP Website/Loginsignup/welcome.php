<?php
session_start();
include "connection.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BlogSpace | Welcome</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), 
                        url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1920&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
        }

        .navbar {
            backdrop-filter: blur(15px);
            background: rgba(255, 255, 255, 0.85) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .post-card {
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            margin-bottom: 25px;
        }

        .post-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 1);
        }

        .hover-bg:hover {
            background-color: rgba(0, 123, 255, 0.1);
            border-radius: 8px;
            transition: 0.2s;
        }

        h4.recent-title {
            color: white;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            font-weight: 700;
        }

        textarea.form-control {
            border-radius: 15px;
            padding: 15px;
            background: #fdfdfd;
            border: 1px solid #ddd;
        }

        .btn-primary {
            border-radius: 12px;
            padding: 10px 30px;
            background: linear-gradient(45deg, #007bff, #0056b3);
            border: none;
            font-weight: bold;
        }

        .sidebar-title {
            font-size: 1.1rem;
            border-bottom: 2px solid #007bff;
            display: inline-block;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#">BlogSpace</a>
        <div class="ms-auto">
            <span class="me-3">Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
            <a href="logout.php" class="btn btn-sm btn-outline-danger rounded-pill px-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row">
        
        <div class="col-md-8">
            <div class="card post-card p-4">
                <h5 class="mb-3 fw-bold text-dark">Share your thoughts</h5>
                <form action="post_logic.php" method="POST">
                    <textarea name="post_content" class="form-control mb-3" rows="3" placeholder="What's happening in class today?" required></textarea>
                    <div class="text-end">
                        <button type="submit" name="submit_post" class="btn btn-primary shadow">Post to Feed</button>
                    </div>
                </form>
            </div>

            <h4 class="mt-5 mb-4 recent-title">Global Feed</h4>
            
            <?php
            // Updated SQL to fetch 'likes' column
            $sql = "SELECT posts.*, users.username FROM posts 
                    JOIN users ON posts.user_id = users.id 
                    ORDER BY posts.created_at DESC";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="card post-card p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; font-weight: bold;">
                                <?php echo strtoupper(substr($row['username'], 0, 1)); ?>
                            </div>
                            <div class="ms-3">
                                <strong class="text-dark d-block">@<?php echo htmlspecialchars($row['username']); ?></strong>
                                <small class="text-muted"><?php echo date('M d, g:i a', strtotime($row['created_at'])); ?></small>
                            </div>
                        </div>
                        <p class="text-dark"><?php echo htmlspecialchars($row['content']); ?></p>
                        
                        <div class="border-top pt-2 d-flex gap-3">
                            <a href="like_logic.php?post_id=<?php echo $row['id']; ?>" class="btn btn-sm text-primary p-0 text-decoration-none hover-bg">
                                <span class="p-2">
                                    👍 <strong>Like</strong> (<?php echo isset($row['likes']) ? $row['likes'] : 0; ?>)
                                </span>
                            </a>

                            <button class="btn btn-sm text-secondary p-0 hover-bg">
                                <span class="p-2">💬 <strong>Comment</strong></span>
                            </button>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p class='text-white'>No posts yet. Be the first to start the trend!</p>";
            }
            ?>
        </div>

        <div class="col-md-4">
            <div class="card post-card p-4 sticky-top" style="top: 90px;">
                <h5 class="sidebar-title fw-bold text-dark">Other Students</h5>
                <div class="list-group list-group-flush">
                    <?php
                    $me = $_SESSION['username'];
                    $user_sql = "SELECT username FROM users WHERE username != '$me' LIMIT 5";
                    $user_result = mysqli_query($conn, $user_sql);

                    if (mysqli_num_rows($user_result) > 0) {
                        while ($user_row = mysqli_fetch_assoc($user_result)) {
                            ?>
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 30px; height: 30px; font-size: 0.8rem;">
                                    <?php echo strtoupper(substr($user_row['username'], 0, 1)); ?>
                                </div>
                                <span class="ms-2 text-dark fw-bold">@<?php echo htmlspecialchars($user_row['username']); ?></span>
                            </div>
                            <?php
                        }
                    } else {
                        echo "<small class='text-muted'>No other students found.</small>";
                    }
                    ?>
                </div>
            </div>
        </div>

    </div> 
</div> 

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>