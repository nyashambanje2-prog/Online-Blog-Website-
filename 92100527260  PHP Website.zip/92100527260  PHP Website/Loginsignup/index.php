<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>College Chronicles | Home</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background: #f4f7f6;
            margin: 0;
        }

        /* Hero Section */
        .hero {
            height: 45vh;
            background: linear-gradient(rgba(10, 30, 60, 0.75), rgba(10, 30, 60, 0.75)), 
                        url('https://images.unsplash.com/photo-1541339907198-e08756ebafe3?auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }

        .hero h1 { 
            font-size: 4rem; 
            margin: 0;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .container {
            max-width: 1100px;
            margin: -60px auto 50px; /* Overlap effect */
            padding: 0 20px;
        }

        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 30px;
        }

        .post-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 12px 30px rgba(0,0,0,0.15);
            transition: 0.4s ease;
        }

        .post-card:hover {
            transform: translateY(-10px);
        }

        .post-image {
            height: 220px;
            width: 100%;
            object-fit: cover;
        }

        .post-content {
            padding: 25px;
        }

        .category-tag {
            color: #c0392b; /* Deep Red for academic vibe */
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .post-content h3 {
            margin: 10px 0;
            color: #1a252f;
            font-size: 22px;
        }

        .post-content p {
            color: #5d6d7e;
            line-height: 1.8;
            font-size: 15px;
        }

        .post-footer {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: #bdc3c7;
        }

        .read-btn {
            color: #1a5276;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>

<section class="hero">
    <h1>College Chronicles</h1>
</section>

<div class="container">
    <div class="blog-grid">
        <div class="post-card">
            <img src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=500&q=60" class="post-image">
            <div class="post-content">
                <span class="category-tag">Academics</span>
                <h3>The Art of the 2:00 AM Study Session</h3>
                <p>Sometimes the best breakthroughs happen when the rest of the world is asleep. Here's how I stay productive...</p>
                <div class="post-footer">
                    <span>Feb 8, 2026</span>
                    <a href="#" class="read-btn">Read Entry →</a>
                </div>
            </div>
        </div>

        <div class="post-card">
            <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=500&q=60" class="post-image">
            <div class="post-content">
                <span class="category-tag">Social</span>
                <h3>Finding Your Circle in a Big Campus</h3>
                <p>Joining clubs wasn't just about the resume; it was about finding people who actually get my jokes...</p>
                <div class="post-footer">
                    <span>Feb 6, 2026</span>
                    <a href="#" class="read-btn">Read Entry →</a>
                </div>
            </div>
        </div>

        <div class="post-card">
            <img src="https://images.unsplash.com/photo-1555854817-5b2260d15050?auto=format&fit=crop&w=500&q=60" class="post-image">
            <div class="post-content">
                <span class="category-tag">Dorm Life</span>
                <h3>Small Space, Big Style</h3>
                <p>How I turned a tiny room with beige walls into a place that actually feels like home...</p>
                <div class="post-footer">
                    <span>Jan 30, 2026</span>
                    <a href="#" class="read-btn">Read Entry →</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>