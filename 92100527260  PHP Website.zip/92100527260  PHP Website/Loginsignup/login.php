<?php
session_start();
include "connection.php";

if (isset($_POST['submit'])) {
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $pass = $_POST['pass'];

    // Search for the user by username or email
    $sql = "SELECT * FROM users WHERE username='$user' OR email='$user'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Check password (Assuming you used password_hash in signup)
        if (password_verify($pass, $row['password'])) {
            $_SESSION['username'] = $row['username'];
            $_SESSION['user_id'] = $row['id']; // CRITICAL: This allows posting!
            header("Location: welcome.php");
            exit();
        } else {
            echo "<script>alert('Invalid Password');</script>";
        }
    } else {
        echo "<script>alert('User not found');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | BlogSpace</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body {
            background: url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1350&q=80') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        h2 { color: #333; margin-bottom: 25px; }
        .input-group { margin-bottom: 20px; text-align: left; }
        label { display: block; margin-bottom: 8px; color: #666; font-size: 14px; }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
        }
        #login-btn {
            width: 100%;
            padding: 12px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        .signup-link { margin-top: 20px; font-size: 14px; color: #777; }
        .nav-item-home { display: block; margin-bottom: 15px; color: #3498db; text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>

<div class="login-card">
    <a href="index.php" class="nav-item-home">← Back to Home</a>
    <h2>Login</h2>
    <form action="login.php" method="POST">
        <div class="input-group">
            <label>Username or Email</label>
            <input type="text" name="user" required placeholder="Enter your username">
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="pass" required placeholder="Enter your password">
        </div>
        <button type="submit" name="submit" id="login-btn">Login</button>
    </form>
    
    <div class="signup-link">
        Don't have an account? <a href="signup.php">Sign Up</a>
    </div>
</div>

</body>
</html>