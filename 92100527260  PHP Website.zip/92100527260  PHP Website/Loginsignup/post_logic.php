<?php
session_start();
include "connection.php";

if (isset($_POST['submit_post'])) {
    $content = mysqli_real_escape_string($conn, $_POST['post_content']);
    
    if (isset($_SESSION['user_id']) && !empty($content)) {
        $user_id = $_SESSION['user_id'];
        $sql = "INSERT INTO posts (user_id, content) VALUES ('$user_id', '$content')";
        
        if (mysqli_query($conn, $sql)) {
            header("Location: welcome.php");
            exit();
        } else {
            die("Database Error: " . mysqli_error($conn));
        }
    } else {
        header("Location: welcome.php");
    }
}
?>