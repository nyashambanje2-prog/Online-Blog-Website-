<?php
 if (isset($_POST['submit'])) {
    include "connection.php"; // Added semicolon
    
    // Match these names to your HTML 'name' attributes
    $username = $_POST['user']; 
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    // Check if username exists
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    $count_user = mysqli_num_rows($result); // Fixed function name

    // Check if email exists
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $count_email = mysqli_num_rows($result); // Fixed function name

    if ($count_user == 0 && $count_email == 0) {
        if ($password == $cpassword) {
            $hash = password_hash($password, PASSWORD_DEFAULT); // Fixed typo & added semicolon
            $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hash')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo '<script>
                    alert("Registration successful!");
                    window.location.href = "login.php";
                </script>';
            }
        } else {
            echo '<script>
                alert("Passwords do not match!!!");
                window.location.href = "signup.php";
            </script>'; 
        }
    } else {
        echo '<script>
            alert("User or Email already exists!!!");
            window.location.href = "signup.php";
        </script>';
    }
 }
?><!DOCTYPE html>
<html>
<head>
    <style>
        body{
            font-family: Arial, sans-serif;
            /* --- BACKGROUND IMAGE SECTION --- */
            background-image: url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1350&q=80'); 
            background-size: cover;        /* Makes the image cover the whole screen */
            background-position: center;   /* Centers the image */
            background-attachment: fixed;  /* Keeps the image still when scrolling */
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        #form-container {
            /* Changed to semi-transparent white so the background peeks through slightly */
            background: rgba(255, 255, 255, 0.95); 
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 10px 30px rgba(0,0,0,0.3);
            width: 450px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        .form-row {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .form-row label {
            width: 160px; /* Fixed width for alignment */
            font-weight: bold;
            color: #444;
        }

        .form-row input {
            flex: 1; /* Makes boxes same size */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        #btn {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            border: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
        }

        #btn:hover {
            background-color: #218838;
            transform: translateY(-1px);
            
            }
    </style>
</head>
<body>

<div id="form-container">
    <h1>Signup Form</h1>
    <form name="form" action="signup.php" method="POST">
        
        <div class="form-row">
            <label for="user">Username</label>
            <input type="text" id="user" name="user" required>
        </div>

        <div class="form-row">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-row">
            <label for="pass">Password</label>
            <input type="password" id="pass" name="pass" required>
        </div>

        <div class="form-row">
            <label for="cpass">Retype Password</label> 
            <input type="password" id="cpass" name="cpass" required>
        </div>

        <input type="submit" id="btn" value="Sign Up" name="submit"/> 
    </form>
</div>

</body>
</html>