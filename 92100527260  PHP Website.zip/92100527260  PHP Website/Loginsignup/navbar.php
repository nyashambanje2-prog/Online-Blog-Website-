<style>
    /* Reset some default styling */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    .navbar {
        background: rgba(255, 255, 255, 0.95); /* Matches your form style */
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 5%;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        position: fixed; /* Stays at the top */
        top: 0;
        width: 100%;
        z-index: 1000;
    }

    .logo {
        font-size: 24px;
        font-weight: bold;
        color: #3498db;
        text-decoration: none;
    }

    .nav-links {
        list-style: none;
        display: flex;
    }

    .nav-links li {
        margin-left: 30px;
    }

    .nav-links a {
        text-decoration: none;
        color: #555;
        font-weight: 500;
        transition: color 0.3s;
    }

    .nav-links a:hover {
        color: #3498db;
    }

    /* Adds padding to the body so content doesn't hide under the sticky navbar */
    body {
        padding-top: 80px; 
    }
</style>

<nav class="navbar">
    <div class="nav-left">
        <a href="index.php" class="logo">BlogSpace</a>
        <a href="index.php" class="nav-item-home">Home</a>
    </div>

    <ul class="nav-links">
        <li><a href="login.php">Login</a></li>
        <li><a href="signup.php">Signup</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>